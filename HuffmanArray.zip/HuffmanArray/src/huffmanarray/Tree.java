/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package huffmanarray;

/**
 *
 * @author dilar
 */
public class Tree {
     public static void main(String[] args)
    {
 
        
        Array_imp obj = new Array_imp();
 
        
        obj.Root("A");
 
        obj.set_Left("B", 0);
        obj.set_Right("C", 0);
        obj.set_Left("D", 1);
        obj.set_Right("E", 1);
        obj.set_Left("F", 2);
        obj.print_Tree();
    }

    
}
