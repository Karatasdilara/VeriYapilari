/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package huffmanarray;

import java.io.*;
import java.lang.*;
import java.util.*;
public class Array_imp {
    
    static int root = 0;
    static String[] str = new String[10];
 
    
    public void Root(String key) { str[0] = key; }
 
    
    public void set_Left(String key, int root)
    {
        int t = (root * 2) + 1;
 
        if (str[root] == null) {
            System.out.printf(
                "bulunamadı\n",
                t);
        }
        else {
            str[t] = key;
        }
    }
 
 
    public void set_Right(String key, int root)
    {
        int t = (root * 2) + 2;
 
        if (str[root] == null) {
            System.out.printf(
                "bulunamadı\n",
                t);
        }
        else {
            str[t] = key;
        }
    }
 

    public void print_Tree()
    {
 
        for (int i = 0; i < 10; i++) {
            if (str[i] != null)
                System.out.print(str[i]);
            else
                System.out.print("-");
        }
    }
    
}
